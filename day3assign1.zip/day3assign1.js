let number = prompt("Enter number:")
 if(number % 2 == 0 )
 {
     console.log(number+ " is even number");
 }
 else
 console.log(number+ " is odd number")

