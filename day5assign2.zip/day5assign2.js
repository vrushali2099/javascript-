class User 
{
    constructor(name,age,email)
    {
        this.name= name;
        this.age = age;
        this.email = email;
        this.lucoins = 0;
        this.courses = [];
    }
    login()
    {
        console.log(`${this.name} has logged in..!!`);
        return this;
    }
    logout()
    {
        console.log(`${this.name} has logged in..!!`);
        return this;

    }

}

class Moderator extends User
{
    addcoins()
    {
        this.lucoins++;
        console.log(`${this.name} has ${this.lucoins} coins..!!`);
        return this;
    }
    removecoins()
    {
        this.lucoins--;
        console.log(`${this.name} has ${this.lucoins} coins..!!`);
        return this;
    }

}  

// mod.addcoins(user1,'10');
// console.log(user1);


class Admin extends Moderator
{
    addcourse(user,course){
        user.courses.push(course);
        console.log(user);
    }

    deletecourse(user,course){
        user.courses.pop(course);
        console.log(user);
    }
}

 let user1 = new User('vrushali',20,'vru@gmail.com')
 let user2 = new User('sweety',22,'sweety@gmail.com')

 let mod = new Moderator('rupali',24,'rups@gmail.com');
 let admin= new Admin('swati',27,'swati@gmailcom');
 users = [user1,user2,mod,admin];
 users.forEach(element => {
     console.log(element);
 });
 
// admin.addcourse(user1,'javascript');
// console.log(user1);
admin.addcourse(user1,'javascript');
console.log(user1);

