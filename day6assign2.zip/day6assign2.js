function multiplicationtable()
{
let i=0;
let num=prompt("enter number:");
for(i=1;i<=10;i++)
{
    document.write(` ${+num} * ${i} = ${num * i}` );
    document.write("<br />");
}
 
}
